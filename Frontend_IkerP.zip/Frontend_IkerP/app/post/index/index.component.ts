import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { Post } from '../post';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {

  posts: Post[] = [];
  userRoleId!: number; 

  constructor(public postService: PostService) { }

  ngOnInit(): void {
    const storedUserProfile = localStorage.getItem('UserProfile');
    if (storedUserProfile) {
      const userProfile = JSON.parse(storedUserProfile);
      this.userRoleId = userProfile.role_id;
    }
    console.log(this.userRoleId)

    this.postService.getAll().subscribe((data: Post[])=>{
      this.posts = data;
      console.log(this.posts);
    }) 
  }

  deletePost(id:number){
    this.postService.delete(id).subscribe(res => {
         this.posts = this.posts.filter(item => item.id !== id);
         console.log('Post deleted successfully!');
    })
  }
}