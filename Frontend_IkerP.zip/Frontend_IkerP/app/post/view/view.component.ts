import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Post } from '../post';
    
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
     
  id!: number;
  post!: Post;
  image:string="";
  categoria:number=0;
  userRoleId!: number;

  private serverURL = "http://localhost:8000/"
    
  /*------------------------------------------
  --------------------------------------------
  Created constructor
  --------------------------------------------
  --------------------------------------------*/
  constructor(
    public postService: PostService,
    private route: ActivatedRoute,
    private router: Router
   ) { }
    
  /**
   * Write code on Method
   *
   * @return response()
   */
  ngOnInit(): void {
    this.id = this.route.snapshot.params['postId'];
    const storedUserProfile = localStorage.getItem('UserProfile');
    if (storedUserProfile) {
      const userProfile = JSON.parse(storedUserProfile);
      this.userRoleId = userProfile.role_id;
    }
    console.log(this.userRoleId)
        
    this.postService.find(this.id).subscribe((data: Post)=>{
      this.post = data;
      this.categoria = this.post.categoria_id
      this.image = this.serverURL+this.post.files[0].file_path;
      console.log(this.image)
    });
  }
  

  firma(id: number) {
    this.postService.firmar(this.id, this.post).subscribe((data:any)=>{
      this.post = data;
      // this.categoria_id = this.post.categoria_id.nombre;
      this.image = this.serverURL+this.post.files[0].file_path;
    })
    // location.reload();
    // this.router.navigate(['/peticiones/', id,'/view']);
  }
  
  cambiarEstado() {
    this.postService.cambiarEstado(this.id).subscribe({
      next: (data) => {
        this.post = data;
        console.log('Estado cambiado con éxito', data);
        window.location.reload();
      },
      error: (error) => {
        console.error('Error al cambiar el estado', error);
      }
    });
  }
}